# Default app config
AWS_REGION = "us-east-1"
FLASK_DEBUG = "false"